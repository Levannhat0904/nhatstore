

<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold">
            Cập nhật người dùng
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('user.update', $user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                <div class="form-group">
                    <label for="name">Họ và tên</label>
                    <input class="form-control" type="text" value="<?php echo e($user->name); ?>" name="name" id="name">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input class="form-control" type="email" name="email" value="<?php echo e($user->email); ?>" disabled id="email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo Form::label('roles', 'Roles'); ?>

                    <?php
                        // $select_role= [5,6];
                        $select_role= $user->roles->pluck('id')->toArray();
                        $option =$role->pluck('name','id')->toArray();
                    ?>
                    <?php echo Form::select('roles[]', $option, $select_role, ['id'=>'roles', 'class'=>'form-control', 'multiple'=>true]); ?>

                </div>

                <button type="submit" value="update" name="btn_update" class="btn btn-primary">Thêm mới</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampps\htdocs\levannhat\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>