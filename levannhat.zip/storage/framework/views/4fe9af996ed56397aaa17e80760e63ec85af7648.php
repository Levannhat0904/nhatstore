
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <?php if('status'): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách sản phẩm</h5>
                <div class="form-search form-inline">
                    <form action="#">
                        <input type="text" name="keyword" value="<?php echo e(request()->input('keyword')); ?>"
                            class="form-control form-search" placeholder="Tìm kiếm tên sản phẩm">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="analytic">
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'active'])); ?>" class="text-primary">Kích hoạt<span
                            class="text-muted">(<?php echo e($count[0]); ?>)</span></a>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'trash'])); ?>" class="text-primary">Vô hiệu hóa<span
                            class="text-muted">(<?php echo e($count[1]); ?>)</span></a>

                </div>
                <form action="<?php echo e(url('admin/product/action')); ?>">

                    <div class="form-action form-inline py-3">
                        <select class="form-control mr-1" name="act" id="">
                            <option>Chọn</option>
                            <?php $__currentLoopData = $list_act; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k); ?>"> <?php echo e($act); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                    </div>
                    <table class="table table-striped table-checkall">
                        <thead>
                            <tr>
                                <th scope="col">
                                    <input name="checkall" type="checkbox">
                                </th>
                                <th scope="col">#</th>
                                <th scope="col">Tên sản phẩm</th>
                                <th scope="col">Màu sắc</th>
                                <th scope="col">Giá</th>
                                <th scope="col">Danh mục</th>
                                <th scope="col">Ngày tạo</th>
                                <th scope="col">Trạng thái</th>
                                <th scope="col">Tác vụ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($products->total() == 0): ?>
                                <td colspan="9">
                                    <p><i style="color: red">*Không có bản ghi nào</i></p>
                                </td>
                            <?php else: ?>
                                <?php
                                    $stt = 0;
                                ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $stt++;
                                    ?>
                                    <tr class="">

                                        <td>
                                            <input type="checkbox" name="list_check[]" value="<?php echo e($product->id); ?>">
                                        </td>
                                        <td><?php echo e($stt); ?></td>
                                        <td><a href="#"><?php echo e($product->name); ?></a></td>
                                        <td>
                                            
                                            <?php
                                                
                                                $k = json_decode($product->color);
                                                foreach ($k as $key => $value) {
                                                    # code...
                                                    if ($key == 0) {
                                                        echo $value;
                                                    } else {
                                                        # code...
                                                        echo ', ' . $value;
                                                    }
                                                    // echo $key;
                                                }
                                            ?>

                                            
                                            
                                        </td>
                                        <td><?php echo e($product->price); ?></td>
                                        <td><?php echo e($product->productCat->cat_item); ?></td>
                                        <td><?php echo e($product->created_at); ?></td>
                                        <?php if($product->total>0): ?>
                                        <td><span class="badge badge-success"><?php echo e("Còn hàng"); ?></span>  </td>
                                        <?php else: ?>
                                        <td><span class="badge badge-warning"><?php echo e("Hết hàng"); ?></span></td>
                                        <?php endif; ?>
                                      
                                        <td>
                                            <a href="<?php echo e(route('admin.edit_product', $product->id)); ?>" class="btn btn-success btn-sm rounded-0 text-white"
                                                type="button" data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                    class="fa fa-edit"></i></a>
                                            <a href="<?php echo e(route('admin.delete_product', $product->id)); ?>"
                                                onclick="return confirm('Bạn có chắc chắn xóa sản phẩm này')"
                                                class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                                data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                    class="fa fa-trash"></i></a>
                                        </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </form>
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampps\htdocs\levannhat\resources\views/admin/product/list.blade.php ENDPATH**/ ?>