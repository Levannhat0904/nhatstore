
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="row">
            <div class="col-4">
                <div class="card">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-header font-weight-bold">
                        Chỉnh sửa quyền
                    </div>
                    <div class="card-body">
                        <?php echo Form::open(['route' =>['permission.update', $permission->id],'method'=>'post']); ?>

                        <div class="form-group">
                            <?php echo Form::label('name', 'Tên quyền'); ?>

                            <?php echo Form::text('name', $permission->name, ['class' => 'form-control', 'id' => 'name']); ?>

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('slug', 'Slug'); ?>

                            <small class="form-text text-muted pb-2">Ví dụ: posts.add</small>
                            <?php echo Form::text('slug',$permission->slug, ['class' => 'form-control', 'id' => 'slug']); ?>

                            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <?php echo Form::label('description', 'Mô tả'); ?>

                            <?php echo Form::text('description',$permission->description, [
                                'class' => 'form-control',
                                'id' => 'description',
                                'row' => 3,
                            ]); ?>

                        </div>
                        <button type="submit" class="btn btn-primary">Cập nhật</button>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
            <div class="col-8">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Danh sách quyền
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Tên quyền</th>
                                    <th scope="col">Slug</th>
                                    <th scope="col">Tác vụ</th>
                                    <!-- <th scope="col">Mô tả</th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moduleName => $modulePermission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td></td>
                                        <td colspan="2"><strong>Module <?php echo e(ucfirst($moduleName)); ?></strong></td>
                                        
                                        <td></td>
                                        <!-- <td></td> -->
                                    </tr>
                                    <?php $__currentLoopData = $modulePermission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td scope="row"><?php echo e($i++); ?></td>
                                            <td>|---<?php echo e($v->name); ?></td>
                                            <td><?php echo e($v->slug); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('permission.edit', $v->id)); ?>"
                                                    class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                                    data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                        class="fa fa-edit"></i></a>
                                                
                                                
                                                <a href="<?php echo e(route('permission.delete', $v->id)); ?>"
                                                    onclick="return confirm('bạn có chăc chắn xóa bản ghi này')"
                                                    class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                                    data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                        class="fa fa-trash"></i></a>
                                                
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampps\htdocs\levannhat\resources\views/admin/permission/edit.blade.php ENDPATH**/ ?>