
<?php $__env->startSection('content'); ?>
    <section class="shoping-cart spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="shoping__cart__table">
                        <table>
                            <thead>
                                <tr>
                                    <th class="shoping__product">Sản Phẩm</th>
                                    <th>Giá</th>
                                    <th>Số lượng</th>
                                    <th>Tổng tiền</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <form action="buy_all_cart" method="get">

                                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="shoping__cart__item">
                                                <img style="width: 80px; height: 80px;" src="<?php echo e(asset($v->options->img)); ?>"
                                                    alt="">
                                                <h5 class=""><?php echo e($v->name); ?> màu<?php echo e($v->options->color); ?></h5>
                                            </td>
                                            <td class="shoping__cart__price">
                                                <?php echo e(number_format($v->price, 0, ',', '.')); ?><?php echo e('vnđ'); ?>

                                            </td>
                                            <td class="shoping__cart__quantity">
                                                <div class="quantity">
                                                    <div class="pro-qty">
                                                        <input type="text" name="qty_cart" data-id="<?php echo e($v->rowId); ?>"
                                                            min="1" id="qty-item-<?php echo e($v->rowId); ?>"
                                                            value=" <?php echo e($v->qty); ?>">
                                                    </div>
                                                </div>
                                            </td>
                                            
                                            <td class="shoping__cart__total" id="total-item-<?php echo e($v->rowId); ?>">
                                                <?php echo e(number_format($v->total, 0, ',', '.')); ?><?php echo e('vnđ'); ?>

                                            </td>
                                            <td class="shoping__cart__item__close">
                                                <span data-rowid="<?php echo e($v->rowId); ?>" class="icon_close "></span>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="row">

                
                <div class="col-lg-12">
                    <div class="shoping__cart__btns" style="margin-top: 30px">
                        <a href="<?php echo e(route('home')); ?>" class="primary-btn cart-btn">Tiếp tục mua</a>
                        <input type="submit" value="Thanh toán ngay" class="primary-btn cart-btn cart-btn-right"
                            style="border: none; margin-left: 20px">
                        <a href="<?php echo e(route('product.shoppingcart')); ?>" class="primary-btn cart-btn cart-btn-right"><span
                                class="icon_loading"></span>
                            Cập nhật giỏ hàng
                        </a>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampps\htdocs\levannhat\resources\views/product/shoppingcart.blade.php ENDPATH**/ ?>