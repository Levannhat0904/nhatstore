
<?php $__env->startSection('content'); ?>
    <section class="h-100 gradient-custom">
        <div class="container w-100 py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-lg-10 col-xl-8">
                    <div class="card" style="border-radius: 10px;">
                        
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <p class="lead fw-normal mb-0" style="color: #a8729a;">Chi tiết đơn hàng</p>
                                <p class="small text-muted mb-0">Mã đơn hàng : <?php echo e($order->orderCode); ?></p>
                            </div>



                            <div class="card shadow-0 border mb-4">
                                <?php $__currentLoopData = $order->order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-2">
                                                <img src="<?php echo e(asset($v->product->img)); ?>" class="img-fluid" alt="Phone">
                                            </div>
                                            <div
                                                class="col-md-2 text-center d-flex justify-content-center align-items-center">
                                                <p class="text-muted mb-0"><?php echo e($v->product->name); ?></p>
                                            </div>
                                            <div
                                                class="col-md-2 text-center d-flex justify-content-center align-items-center">
                                                <p class="text-muted mb-0 small">Màu sắc <?php echo e($v->color); ?></p>
                                            </div>
                                            <div
                                                class="col-md-2 text-center d-flex justify-content-center align-items-center">
                                                <p class="text-muted mb-0 small">Số lượng: <?php echo e($v->qty_buy); ?></p>
                                            </div>
                                            <div
                                                class="col-md-2 text-center d-flex justify-content-center align-items-center">
                                                <p class="text-muted mb-0 small">Giá: <?php echo e($v->price); ?></p>
                                            </div>
                                            <div
                                                class="col-md-2 text-center d-flex justify-content-center align-items-center">
                                                <p class="text-muted mb-0 small">Tổng tiền: <?php echo e($v->qty_buy * $v->price); ?>

                                                </p>
                                            </div>
                                        </div>
                                        <hr class="mb-4" style="background-color: #e0e0e0; opacity: 1;">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="row d-flex align-items-center">
                                    <div class="col-md-2">
                                        <p class="text-muted mb-0 ">Trạng thái đơn hàng</p>
                                    </div>
                                    <div class="col-md-10">
                                        <div class="d-flex justify-content-around mb-1">
                                            <select name="status">
                                                <option <?php if($order->status=="Đang vận chuyển"){echo "selected";} ?>
                                                    value="Đang vận chuyển">Đang vận chuyển</option>
                                                <option
                                                    <?php if ($order->status=="Đang chờ gửi hàng"){echo "selected";} ?>
                                                    value="Đang chờ gửi hàng">Đang chờ gửi hàng</option>
                                                <option <?php if ($order->status=="Đã hủy"){echo "selected";} ?>
                                                    value="Đã hủy">Đã hủy</option>
                                                <option <?php if ($order->status=="Thành công"){echo "selected";} ?>
                                                    value="Thành công">Thành công</option>
                                            </select>
                                            <button data-id="<?php echo e($order->id); ?> "id="status">Cập nhật</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                            
                 

                        <div class="d-flex justify-content-between pt-2">
                            <p class="fw-bold mb-0">Họ tên:<?php echo e($order->username); ?> </p>
                            <p class="text-muted mb-0"><span class="fw-bold me-4">Tổng số lượng: <?php echo e($order->total); ?></span>
                            </p>
                        </div>
                        <div class="d-flex justify-content-between pt-2">
                            <p class="fw-bold mb-0">Email: <?php echo e($order->email); ?></p>
                            <p class="text-muted mb-0"><span class="fw-bold me-4">Tổng tiền:
                                    <?php echo e($order->total_order - 30000); ?>

                        </div>

                        <div class="d-flex justify-content-between pt-2">
                            <p class="text-muted mb-0">Số điện thoại: <?php echo e($order->phone_number); ?></p>
                            <p class="text-muted mb-0"><span class="fw-bold me-4">Phí vận chuyển</span> 30.000vnd</p>
                        </div>

                        <div class="d-flex justify-content-between">
                            <p class="text-muted mb-0">Ngày đặt hàng: <?php echo e($order->created_at); ?></p>
                            <p class="text-muted mb-0"><span class="fw-bold me-4">Thành tiền<?php echo e($order->total_order); ?>

                        </div>

                        <div class="d-flex justify-content-between mb-5">
                            <p class="text-muted mb-0">Phương thức thanh toán : thanh toán khi nhận hàng</p>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampps\htdocs\levannhat\resources\views/admin/order/detail.blade.php ENDPATH**/ ?>