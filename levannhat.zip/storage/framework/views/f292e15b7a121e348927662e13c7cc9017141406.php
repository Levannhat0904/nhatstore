
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
            <h5 class="m-0 ">Danh sách đơn hàng</h5>
            <div class="form-search form-inline">
                <form action="#">
                    <input type="text" class="form-control form-search" value="<?php echo e(request()->input('key')); ?>" name="key" placeholder="Tìm kiếm">
                    <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                </form>
            </div>
        </div>
        <div class="card-body">
            <div class="analytic">
                <div class="analytic">
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'shipping'])); ?>" class="text-primary">Đang vận chuyển<span
                            class="text-muted">(<?php echo e($count[0]); ?>)</span></a>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'waiting'])); ?>" class="text-primary">Đang chờ gửi hàng<span
                            class="text-muted">(<?php echo e($count[1]); ?>)</span></a>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'cancel'])); ?>" class="text-primary">Đã hủy<span
                            class="text-muted">(<?php echo e($count[2]); ?>)</span></a>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'success'])); ?>" class="text-primary">Thành công<span
                            class="text-muted">(<?php echo e($count[3]); ?>)</span></a>
                   
                </div>
            </div>
            
            <div style=" margin: 20px"></div>
            <h5 style="color: red"><i>*Bấm vào mã đơn hàng để xem chi tiết đơn hàng</i></h5>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Mã đơn hàng</th>
                        <th scope="col">Khách hàng</th>
                        
                        <th scope="col">Số lượng</th>
                        <th scope="col">Giá trị</th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Thời gian</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php if($orders->total()>0): ?>
                        
                    
                    <?php
                        $t = 0;
                    ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php
                                $t++;
                            ?>
                            <th scope="row"><?php echo e($t); ?></th>
                            <td><a href="<?php echo e(route('order_detail',$order->id)); ?>"><?php echo e($order->orderCode); ?></a></td>
                            <td>
                                <?php echo e($order->username); ?> <br>
                                <?php echo e($order->phone_number); ?>  
                            </td>
                            
                            <td><?php echo e($order->total); ?></td>
                            <td><?php echo e(number_format($order->total_order, 0, ',', '.')); ?><?php echo e('vnđ'); ?></td>
                            <?php if($order->status == 'Thành công'): ?>
                                <td><span class="badge badge-success"><?php echo e($order->status); ?></span></td>
                            <?php else: ?>
                                <td><span class="badge badge-warning"><?php echo e($order->status); ?></span></td>
                            <?php endif; ?>
                            <td><?php echo e($order->created_at); ?></td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td style="color: red" colspan="8"><i>*Không có bản ghi nào</i></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($orders->links()); ?>

            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampps\htdocs\levannhat\resources\views/admin/order/list.blade.php ENDPATH**/ ?>